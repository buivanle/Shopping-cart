import 'package:flutter/material.dart';
import 'cart.dart';

class CartScreen extends StatelessWidget {
  final Cart cart;

  CartScreen(this.cart);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Danh sách giỏ hàng'),
      ),
      body: ListView.builder(
        itemCount: cart.products.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(cart.products[index].name),
            subtitle: Text('Số lượng: ${cart.products[index].quantity}'),
            trailing: ElevatedButton(
              child: Text('Xóa khỏi giỏ hàng'),
              onPressed: () {
                cart.removeFromCart(cart.products[index].name);
              },
            ),
          );
        },
      ),
    );
  }
}
