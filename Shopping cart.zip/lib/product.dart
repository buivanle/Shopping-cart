class Product {
  String name;
  int quantity;

  Product(this.name, this.quantity);
}
