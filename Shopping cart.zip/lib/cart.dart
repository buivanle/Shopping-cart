import 'product.dart';

class Cart {
  List<Product> products = [];

  void addToCart(String productName) {
    Product product = products.firstWhere(
      (item) => item.name == productName,
      orElse: () => Product('', 0),
    );

    if (product != null) {
      product.quantity++;
    } else {
      products.add(Product(productName, 1));
    }
  }

  void removeFromCart(String productName) {
    products.removeWhere((item) => item.name == productName);
  }

  int getProductQuantity(String productName) {
    Product product = products.firstWhere(
      (item) => item.name == productName,
      orElse: () => Product('', 0),
    );

    return product != null ? product.quantity : 0;
  }
}
