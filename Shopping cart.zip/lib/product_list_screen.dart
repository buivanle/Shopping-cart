import 'package:flutter/material.dart';
import 'cart.dart';
import 'cart_screen.dart';

class ProductListScreen extends StatelessWidget {
  final Cart cart;

  ProductListScreen(this.cart);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Danh sách sản phẩm'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CartScreen(cart),
                ),
              );
            },
          ),
        ],
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text('Sản phẩm 1'),
            subtitle:
                Text('Số lượng: ${cart.getProductQuantity('Sản phẩm 1')}'),
            trailing: ElevatedButton(
              child: Text('Thêm vào giỏ hàng'),
              onPressed: () {
                cart.addToCart('Sản phẩm 1');
              },
            ),
          ),
          ListTile(
            title: Text('Sản phẩm 2'),
            subtitle:
                Text('Số lượng: ${cart.getProductQuantity('Sản phẩm 2')}'),
            trailing: ElevatedButton(
              child: Text('Thêm vào giỏ hàng'),
              onPressed: () {
                cart.addToCart('Sản phẩm 2');
              },
            ),
          ),
          // Thêm các sản phẩm khác tương tự
        ],
      ),
    );
  }
}
